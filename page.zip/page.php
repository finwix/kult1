<?php get_header(); ?>


			<div class="container" id="content_index">
				<style type="text/css">.wpshop_count,.wpshop_button{display: none;}</style>

			<?php if(have_posts()): ?>
			<?php while(have_posts()): the_post(); ?>
				<?php the_post_thumbnail(); ?>
				<?php the_title(); ?>
				<?php the_content(); ?> 
			<?php endwhile; ?>

			<?php endif; ?>	

			<div class="clr"></div>


&nbsp;
			</div>
		</div>

		 <?php get_footer(); ?>
		
